if RyzxA==B30_A
    disp('Polożenie początkowe w punkcie A: ')
    disp('Macierz orientacj B30_A zgadza się z macierzą orientacji')
else
    disp('Polożenie początkowe w punkcie A: ')
    disp('Macierz orientacj B30_A nie zgadza się z macierzą orientacji')
end;

if RyzxB==B30_B
    disp('Polożenie końcowe w punkcie B: ')
    disp('Macierz orientacj B30_B zgadza się z macierzą orientacji')
else
    disp('Polożenie końcowe w punkcie B: ')
    disp('Macierz orientacj B30_B nie zgadza się z macierzą orientacji')
end;