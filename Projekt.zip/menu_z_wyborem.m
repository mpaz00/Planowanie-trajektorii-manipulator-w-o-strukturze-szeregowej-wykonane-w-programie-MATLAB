m=menu('Wybierz typ planowania', 'Wedlug wielomianu 3 stopnia', 'Wedlug wielomianu 5 stopnia', 'Wedlug wielomianu 7 stopnia', 'Wedlug wielomianu 4-3-4')
    if (m==1)
    disp('Planowanie trajektorii manipulatora przy wykorzystaniu wielomianu stopnia 3')
    wielomian_3
    elseif (m==2)
    disp('Planowanie trajektori manipulatora z wykorzystaniem wielomianu stopnia 5')
    wielomian_5    
    elseif (m==3)
    disp('Planowanie trajektorii manipulatora z wykorzystaniem wielomianu stopnia 7')
    wielomian_7  
    elseif (m==4)
    disp('Planowanie trajektorii manipulatora za pomocą wielomianu stopnia 4-3-4 ')
    wielomian4_3_4   
    end    
