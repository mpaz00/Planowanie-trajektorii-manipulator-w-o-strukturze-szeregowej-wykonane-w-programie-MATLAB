% planowanie trajektorii - wielomian stopnia 4-3-4
tau=[0:0.01:1];

a10=pozycjaA(1,1);
a11=0;
a12=0;
a13=pozycjaB(1,1)/2 - (pozycjaA(1,1))/2;
a14=(pozycjaA(1,1))/4 - pozycjaB(1,1)/4;
a20=pozycjaB(1,1)/4 + 3*pozycjaA(1,1)/4;
a21=pozycjaB(1,1)/2 - pozycjaA(1,1)/2;
a22=0;
a23=0;
a30=(3*pozycjaB(1,1))/4 + (pozycjaA(1,1))/4;
a31=pozycjaB(1,1)/2 - pozycjaA(1,1)/2;
a32=0;
a33=(pozycjaA(1,1))/2 - pozycjaB(1,1)/2;
a34=pozycjaB(1,1)/4 - (pozycjaA(1,1))/4;

qtau411=a10+a11*tau+a12*tau.^2+a13*tau.^3+a14*tau.^4;
qtau412=a20+a21*tau+a22*tau.^2+a23*tau.^3;
qtau413=a30+a31*tau+a32*tau.^2+a33*tau.^3+a34*tau.^4;

dqtau411=a11+2*a12*tau+3*a13*tau.^2+4*a14*tau.^3;
dqtau412=a21+2*a22*tau+3*a23*tau.^2;
dqtau413=a31+2*a32*tau+3*a33*tau.^2+4*a34*tau.^3;

ddqtau411=2+6*a13*tau+12*a14*tau.^2;
ddqtau412=2+6*a23*tau;
ddqtau413=2+6*a33*tau+12*a34*tau.^2;

a10=pozycjaA(1,2);
a11=0;
a12=0;
a13=pozycjaB(1,2)/2 - (pozycjaA(1,2))/2;
a14=(pozycjaA(1,2))/4 - pozycjaB(1,2)/4;
a20=pozycjaB(1,2)/4 + 3*pozycjaA(1,2)/4;
a21=pozycjaB(1,2)/2 - pozycjaA(1,2)/2;
a22=0;
a23=0;
a30=(3*pozycjaB(1,2))/4 + (pozycjaA(1,2))/4;
a31=pozycjaB(1,2)/2 - pozycjaA(1,2)/2;
a32=0;
a33=(pozycjaA(1,2))/2 - pozycjaB(1,2)/2;
a34=pozycjaB(1,2)/4 - (pozycjaA(1,2))/4;
qtau421=a10+a11*tau+a12*tau.^2+a13*tau.^3+a14*tau.^4;
qtau422=a20+a21*tau+a22*tau.^2+a23*tau.^3;
qtau423=a30+a31*tau+a32*tau.^2+a33*tau.^3+a34*tau.^4;
dqtau421=a11+2*a12*tau+3*a13*tau.^2+4*a14*tau.^3;
dqtau422=a21+2*a22*tau+3*a23*tau.^2;
dqtau423=a31+2*a32*tau+3*a33*tau.^2+4*a34*tau.^3;
ddqtau421=2+6*a13*tau+12*a14*tau.^2;
ddqtau422=2+6*a23*tau;
ddqtau423=2+6*a33*tau+12*a34*tau.^2;

a10=pozycjaA(1,3);
a11=0;
a12=0;
a13=pozycjaB(1,3)/2 - (pozycjaA(1,3))/2;
a14=(pozycjaA(1,3))/4 - pozycjaB(1,3)/4;
a20=pozycjaB(1,3)/4 + 3*pozycjaA(1,3)/4;
a21=pozycjaB(1,3)/2 - pozycjaA(1,3)/2;
a22=0;
a23=0;
a30=(3*pozycjaB(1,3))/4 + (pozycjaA(1,3))/4;
a31=pozycjaB(1,3)/2 - pozycjaA(1,3)/2;
a32=0;
a33=(pozycjaA(1,3))/2 - pozycjaB(1,3)/2;
a34=pozycjaB(1,3)/4 - (pozycjaA(1,3))/4;
qtau431=a10+a11*tau+a12*tau.^2+a13*tau.^3+a14*tau.^4;
qtau432=a20+a21*tau+a22*tau.^2+a23*tau.^3;
qtau433=a30+a31*tau+a32*tau.^2+a33*tau.^3+a34*tau.^4;
dqtau431=a11+2*a12*tau+3*a13*tau.^2+4*a14*tau.^3;
dqtau432=a21+2*a22*tau+3*a23*tau.^2;
dqtau433=a31+2*a32*tau+3*a33*tau.^2+4*a34*tau.^3;
ddqtau431=2+6*a13*tau+12*a14*tau.^2;
ddqtau432=2+6*a23*tau;
ddqtau433=2+6*a33*tau+12*a34*tau.^2;

%wykresy przesunięcia 
subplot(3,3,1)
plot([tau tau+1 tau+2],[qtau411 qtau412 qtau413],'g',[1 2],[qtau411(1,end) qtau412(1,end)],'g+')
xlabel('\it\tau')
ylabel('theta1')

subplot(3,3,2)
plot([tau tau+1 tau+2],[qtau421 qtau422 qtau423],'g',[1 2],[qtau421(1,end) qtau422(1,end)],'g+')
xlabel('\it\tau')
ylabel('theta2')

subplot(3,3,3)
plot([tau tau+1 tau+2],[qtau431 qtau432 qtau433],'g',[1 2],[qtau431(1,end) qtau432(1,end)],'g+')
xlabel('\it\tau')
ylabel('lambda3')

%wykresy prędkości 
subplot(3,3,4)
plot([tau tau+1 tau+2],[dqtau411 dqtau412 dqtau413],'b',[1 2],[dqtau411(1,end) dqtau412(1,end)],'b+')
xlabel('\it\tau')
ylabel('dtheta1')

subplot(3,3,5)
plot([tau tau+1 tau+2],[dqtau421 dqtau422 dqtau423],'b',[1 2],[dqtau421(1,end) dqtau422(1,end)],'b+')
xlabel('\it\tau')
ylabel('dtheta2')

subplot(3,3,6)
plot([tau tau+1 tau+2],[dqtau431 dqtau432 dqtau433],'b',[1 2],[dqtau431(1,end) dqtau432(1,end)],'b+')
xlabel('\it\tau')
ylabel('dlambda3')

%wykresy przyspieszeń 
subplot(3,3,7)
plot([tau tau+1 tau+2],[ddqtau411 ddqtau412 ddqtau413],'r',[1 2],[ddqtau411(1,end) ddqtau412(1,end)],'r+')
xlabel('\it\tau')
ylabel('ddtheta1')

subplot(3,3,8)
plot([tau tau+1 tau+2],[ddqtau421 ddqtau422 ddqtau423],'r',[1 2],[ddqtau421(1,end) ddqtau422(1,end)],'r+')
xlabel('\it\tau')
ylabel('ddtheta2')

subplot(3,3,9)
plot([tau tau+1 tau+2],[ddqtau431 ddqtau432 ddqtau433],'r',[1 2],[ddqtau431(1,end) ddqtau432(1,end)],'r+')
xlabel('\it\tau')
ylabel('ddlambda3')