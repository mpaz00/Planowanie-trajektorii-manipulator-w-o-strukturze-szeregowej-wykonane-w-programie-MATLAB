%współrzędne wektorow
disp('Ze względu na wymiary manipulatora maksymalne wartości sa w przedziale 0-1 [m]')
disp('Wartości współrzędnych dla wektora A')
px_A=input('podaj wartość px [m]: ')
py_A=input('podaj wartość py [m]: ')
pz_A=input('podaj wartość pz [m]: ')
%polozenie_B
disp('Wartości współrzędnych dla wektora B')
px_B=input('podaj wartość px [m]: ')
py_B=input('podaj wartość py [m]: ')
pz_B=input('podaj wartość pz [m]: ')
disp('Wartości współrzędnych dla wektora W')
px_W=input('podaj wartość px [m]: ')
py_W=input('podaj wartość py [m]: ')
pz_W=input('podaj wartość pz [m]: ')
disp('Wartości współrzędnych dla wektora R')
px_R=input('podaj wartość px [m]: ')
py_R=input('podaj wartość py [m]: ')
pz_R=input('podaj wartość pz [m]: ')
          
%czasy
t0=input('Wprowadz wartość czasu poczatkowego [s]=')
tk=input('Wprowadz wartość czasu końcowego [s]= ')
tr=input('Wprowadz wartość czasu dla wektora W [s]=')
tw=input('Wprowadz wartość czasu dla wektora R [s]= ')
                       

%kąty wraz z przeliczeniem na radiany
%konwencja: YZX
disp('Wartości katow dla położenia A')
alpha=input('podaj wartość kąta alfa [stopnie]: ')                    
alpha_A=(alpha.*pi)./180;
beta=input('podaj wartość kąta beta [stopnie]: ')                   
beta_A=(beta.*pi)./180;
gamma=input('podaj wartość kąta gamma [stopnie]: ')                  
gamma_A=(gamma.*pi)./180;
disp('Wartości katow dla położenia B')
alpha1=input('podaj wartość kąta alfa [stopnie]: ')                    
alpha_B=(alpha1.*pi)./180;
beta1=input('podaj wartość kąta beta [stopnie]: ')                     
beta_B=(beta1.*pi)./180;
gamma1=input('podaj wartość kąta gamma [stopnie]: ')                    
gamma_B=(gamma1.*pi)./180;



