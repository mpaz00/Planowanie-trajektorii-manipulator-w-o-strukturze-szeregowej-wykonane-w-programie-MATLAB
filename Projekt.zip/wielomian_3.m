%planowanie trajektorii - wielomian stopnia 3


t=[t0:0.01:tk];
tau=t./tk;

a0=pozycjaA(1,1);
a1=0;
a2=3.*(pozycjaB(1,1)-pozycjaA(1,1));
a3=2.*(pozycjaA(1,1)-pozycjaB(1,1));
qtau1=a0+a1.*tau+a2.*(tau).^2+a3.*(tau).^3;
dqtau1=(a1+2.*a2.*tau+3.*a3.*(tau).^2)/tk;

a0=pozycjaA(1,2);
a1=0;
a2=3.*(pozycjaB(1,2)-pozycjaA(1,2));
a3=2.*(pozycjaA(1,2)-pozycjaB(1,2));
qtau2=a0+a1.*tau+a2.*(tau).^2+a3.*(tau).^3;
dqtau2=(a1+2.*a2.*tau+3.*a3.*(tau).^2)/tk;

a0=pozycjaA(1,3);
a1=0;
a2=3.*(pozycjaB(1,3)-pozycjaA(1,3));
a3=2.*(pozycjaA(1,3)-pozycjaB(1,3));
qtau3=a0+a1*tau+a2*(tau).^2+a3*(tau).^3;
dqtau3=(a1+2*a2*tau+3*a3*(tau).^2)/tk;

 
subplot(2,3,1)
plot(tau,qtau1,'g')
xlabel('\it\tau')
ylabel('theta1')

subplot(2,3,2)
plot(tau,qtau2,'g')
xlabel('\it\tau')
ylabel('theta2')

subplot(2,3,3)
plot(tau,qtau3,'g')
xlabel('\it\tau')
ylabel('lambda3')


subplot(2,3,4)
plot(tau,dqtau1,'b')
xlabel('\it\tau')
ylabel('dtheta1')

subplot(2,3,5)
plot(tau,dqtau2,'b')
xlabel('\it\tau')
ylabel('dtheta2')

subplot(2,3,6)
plot(tau,dqtau3,'b')
xlabel('\it\tau')
ylabel('dlambda3')




