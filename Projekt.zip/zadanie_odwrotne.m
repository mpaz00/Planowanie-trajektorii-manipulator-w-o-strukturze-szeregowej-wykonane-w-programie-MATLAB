% rx, ry, rz - zapis symboliczny
%rxnum, rynum, rznum - zapis numeryczny

syms theta1 theta2 theta3...
    lambda1 lambda2 lambda3...
    alpha1 alpha2 alpha3...
    l1 l2 l3 ;  %symbolic objects

theta=[theta1 theta2 theta3];
lambda=[lambda1 lambda2 lambda3];
alpha=[alpha1 alpha2 alpha3];
l=[l1 l2 l3];

k=size(theta);  %wymiary macierzy theta
n=k(2);
for i=1:n
    A=matrixA(l(i),lambda(i),alpha(i),theta(i)); %tworzenie macierzy A
    eval(['A' num2str(i) '=A']) %wpisuje indeksację a1,a2,a3
end
disp('Macierz przejścia z układu 3 do układu 0')
    T30s=A1*A2*A3

disp('Wektor pozycji chwytaka względem układu 0')
    p30s=T30s(1:3,4) %wybranie wektora pozycji - 3 pierwsze wiersze czwartej kolumny macierzy T


disp('Wartości stałe manipulatora')

%dane manipulatora
    lambda1=sym(0);
    lambda2=sym(1);
    theta3=sym(3/2*pi);
    l1=sym(1);
    l2=sym(0);
    l3=sym(1);
    alpha1=sym(3/2*pi);
    alpha2=sym(0);
    alpha3=sym(3/2*pi);
 
disp('Wartości wektora pozycji na postawie zadania prostego kinematyki dla theta1=20 [stopni] theta2=40 [stopni] lambda3=2[m]')
T30s=subs(T30s);
p30s=subs(p30s);


disp('Wyznaczamy rx ry rz na postawie wetora pozycji p30')
rx=subs(p30s(1))
ry=subs(p30s(2))
rz=subs(p30s(3))


for j=1:4
    if j==1
        rxnum=px_A;
        rynum=py_A;
        rznum=pz_A;
    elseif j==2
        rxnum=px_R;
        rynum=py_R;
        rznum=pz_R;
    elseif j==3
         rxnum=px_W;
        rynum=py_W;
        rznum=pz_W;
    elseif j==4
        rxnum=px_B;
        rynum=py_B;
        rznum=pz_B;
    end

% rxnum + posta numeryczna
disp('Równania')
row1=rx-rxnum
row2=ry-rynum
row3=rz-rznum


row1=rx-rxnum
row2=ry-rynum
row3=rz-rznum


theta2sym=solve(row3==0)
theta2=subs(theta2sym)
theta22=double(theta2)

for i=1:2
syms theta1
theta2=theta22(i)

row1_2=cos(theta1)*row1+row2*sin(theta1)
row1_2_simply=simplify(row1_2)
row1_2_sub=subs(row1_2_simply)

theta1sym=solve(row1_2_simply,theta1)
theta1_simply=simplify(theta1sym)
theta1=subs(theta1_simply)
theta1=simplify(theta1)

disp('sprawdzenie czy rozwiązania zawierają części urojone')
if imag(double(theta1))<10^(-7)
    if imag(double(theta1))>-10^(-7)

theta_1=real(double(theta1))
    
end
end
theta11(2*i-1)=theta_1(1)
theta11(2*i)=theta_1(2)
clear theta1

end

theta22p=theta22
for i=1:2
theta22(2*i-1)=theta22p(i)
theta22(2*i)=theta22p(i)

end



for i=1:4
syms lambda3
theta1=theta11(i)
theta2=theta22(i)

lambda3=solve(row1,lambda3)
lambda_3=subs(lambda3)
lambda_3=simplify(lambda_3)
lambda3=double(lambda_3)

disp('sprawdzenie czy rozwiązania zawierają części urojone')
if imag(double(lambda3))<10^(-7)
    if imag(double(lambda3))>-10^(-7)

lambda_3=real(double(lambda3))
    
end
end
lambda33(i)=lambda_3
clear lambda3

end



rozwiazanie=[theta22(1) theta11(1) lambda33(1);
        theta22(2) theta11(2) lambda33(2);
        theta22(3) theta11(3) lambda33(3)
        theta22(4) theta11(4) lambda33(4);]
    
clear theta1 theta2 lambda3
syms theta1 theta2 lambda3
        
    if j==1
        pozycjaA=rozwiazanie;
    elseif j==2
        pozycjaR=rozwiazanie;
    elseif j==3
        pozycjaW=rozwiazanie;
    elseif j==4
        pozycjaB=rozwiazanie;
    end;

end;
    
    
    