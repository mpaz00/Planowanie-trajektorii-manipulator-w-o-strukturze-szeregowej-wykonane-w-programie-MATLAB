%planowanie trajektorii - wielomian stopnia 7

t=[t0:0.01:tk];
tau=t./tk;
tauw=tw/tk;
taur=tr/tk;

a0=pozycjaA(1,1);
a1=0;
a2=0;
a3=(pozycjaR(1,1)*tauw)/(taur^3*(taur - tauw)*(taur - 1)^3) - (pozycjaA(1,1)*(10*taur^3*tauw^3 + 6*taur^3*tauw^2 + 3*taur^3*tauw + taur^3 + 6*taur^2*tauw^3 + 3*taur^2*tauw^2 + taur^2*tauw + 3*taur*tauw^3 + taur*tauw^2 + tauw^3))/(taur^3*tauw^3) - (pozycjaW(1,1)*taur)/(tauw^3*(taur - tauw)*(tauw - 1)^3) + (pozycjaB(1,1)*taur*tauw*(10*taur^2*tauw^2 - 24*taur^2*tauw + 15*taur^2 - 24*taur*tauw^2 + 57*taur*tauw - 35*taur + 15*tauw^2 - 35*tauw + 21))/((taur - 1)^3*(tauw - 1)^3);
a4=(pozycjaA(1,1)*(15*taur^3*tauw^3 + 18*taur^3*tauw^2 + 9*taur^3*tauw + 3*taur^3 + 18*taur^2*tauw^3 + 15*taur^2*tauw^2 + 6*taur^2*tauw + taur^2 + 9*taur*tauw^3 + 6*taur*tauw^2 + taur*tauw + 3*tauw^3 + tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,1)*(15*taur^3*tauw^3 - 27*taur^3*tauw^2 + 15*taur^3 - 27*taur^2*tauw^3 + 42*taur^2*tauw^2 + 15*taur^2*tauw - 35*taur^2 + 15*taur*tauw^2 - 35*taur*tauw + 21*taur + 15*tauw^3 - 35*tauw^2 + 21*tauw))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaR(1,1)*(3*tauw + 1))/(taur^3*(taur - tauw)*(taur - 1)^3) + (pozycjaW(1,1)*(3*taur + 1))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a5=(pozycjaR(1,1)*(3*tauw + 3))/(taur^3*(taur - tauw)*(taur - 1)^3) - (pozycjaA(1,1)*(6*taur^3*tauw^3 + 18*taur^3*tauw^2 + 9*taur^3*tauw + 3*taur^3 + 18*taur^2*tauw^3 + 27*taur^2*tauw^2 + 12*taur^2*tauw + 3*taur^2 + 9*taur*tauw^3 + 12*taur*tauw^2 + 3*taur*tauw + 3*tauw^3 + 3*tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,1)*(27*taur^3*tauw - 6*taur^3*tauw^3 - 24*taur^3 + 27*taur^2*tauw^2 - 66*taur^2*tauw + 42*taur^2 + 27*taur*tauw^3 - 66*taur*tauw^2 + 42*taur*tauw - 24*tauw^3 + 42*tauw^2 - 21))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaW(1,1)*(3*taur + 3))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a6=(pozycjaA(1,1)*(6*taur^3*tauw^2 + 3*taur^3*tauw + taur^3 + 6*taur^2*tauw^3 + 21*taur^2*tauw^2 + 10*taur^2*tauw + 3*taur^2 + 3*taur*tauw^3 + 10*taur*tauw^2 + 3*taur*tauw + tauw^3 + 3*tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,1)*(6*taur^3*tauw^2 - 15*taur^3*tauw + 10*taur^3 + 6*taur^2*tauw^3 - 15*taur^2*tauw^2 + 10*taur^2*tauw - 15*taur*tauw^3 + 10*taur*tauw^2 + 42*taur*tauw - 42*taur + 10*tauw^3 - 42*tauw + 35))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaR(1,1)*(tauw + 3))/(taur^3*(taur - tauw)*(taur - 1)^3) + (pozycjaW(1,1)*(taur + 3))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a7=(pozycjaB(1,1)*(6*taur^2*tauw^2 - 15*taur^2*tauw + 10*taur^2 - 15*taur*tauw^2 + 37*taur*tauw - 24*taur + 10*tauw^2 - 24*tauw + 15))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaA(1,1)*(6*taur^2*tauw^2 + 3*taur^2*tauw + taur^2 + 3*taur*tauw^2 + taur*tauw + tauw^2))/(taur^3*tauw^3) + pozycjaR(1,1)/(taur^3*(taur - tauw)*(taur - 1)^3) - pozycjaW(1,1)/(tauw^3*(taur - tauw)*(tauw - 1)^3);
qtau31=a0+a1*tau+a2*tau.^2+a3*tau.^3+a4*tau.^4+a5*tau.^5+a6*tau.^6+a7*tau.^7;
dqtau31=(a1+2*a2*tau+3*a3*tau.^2+4*a4*tau.^3+5*a5*tau.^4+6*a6*tau.^5+7*a7*tau.^6)./tk;
ddqtau31=(2*a2+6*a3*tau+12*a4*tau.^2+20*a5*tau.^3+30*a6*tau.^4+42*a7*tau.^5)./tk.^2;

a0=pozycjaA(1,2);
a1=0;
a2=0;
a3=(pozycjaR(1,2)*tauw)/(taur^3*(taur - tauw)*(taur - 1)^3) - (pozycjaA(1,2)*(10*taur^3*tauw^3 + 6*taur^3*tauw^2 + 3*taur^3*tauw + taur^3 + 6*taur^2*tauw^3 + 3*taur^2*tauw^2 + taur^2*tauw + 3*taur*tauw^3 + taur*tauw^2 + tauw^3))/(taur^3*tauw^3) - (pozycjaW(1,2)*taur)/(tauw^3*(taur - tauw)*(tauw - 1)^3) + (pozycjaB(1,2)*taur*tauw*(10*taur^2*tauw^2 - 24*taur^2*tauw + 15*taur^2 - 24*taur*tauw^2 + 57*taur*tauw - 35*taur + 15*tauw^2 - 35*tauw + 21))/((taur - 1)^3*(tauw - 1)^3);
a4=(pozycjaA(1,2)*(15*taur^3*tauw^3 + 18*taur^3*tauw^2 + 9*taur^3*tauw + 3*taur^3 + 18*taur^2*tauw^3 + 15*taur^2*tauw^2 + 6*taur^2*tauw + taur^2 + 9*taur*tauw^3 + 6*taur*tauw^2 + taur*tauw + 3*tauw^3 + tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,2)*(15*taur^3*tauw^3 - 27*taur^3*tauw^2 + 15*taur^3 - 27*taur^2*tauw^3 + 42*taur^2*tauw^2 + 15*taur^2*tauw - 35*taur^2 + 15*taur*tauw^2 - 35*taur*tauw + 21*taur + 15*tauw^3 - 35*tauw^2 + 21*tauw))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaR(1,2)*(3*tauw + 1))/(taur^3*(taur - tauw)*(taur - 1)^3) + (pozycjaW(1,2)*(3*taur + 1))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a5=(pozycjaR(1,2)*(3*tauw + 3))/(taur^3*(taur - tauw)*(taur - 1)^3) - (pozycjaA(1,2)*(6*taur^3*tauw^3 + 18*taur^3*tauw^2 + 9*taur^3*tauw + 3*taur^3 + 18*taur^2*tauw^3 + 27*taur^2*tauw^2 + 12*taur^2*tauw + 3*taur^2 + 9*taur*tauw^3 + 12*taur*tauw^2 + 3*taur*tauw + 3*tauw^3 + 3*tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,2)*(27*taur^3*tauw - 6*taur^3*tauw^3 - 24*taur^3 + 27*taur^2*tauw^2 - 66*taur^2*tauw + 42*taur^2 + 27*taur*tauw^3 - 66*taur*tauw^2 + 42*taur*tauw - 24*tauw^3 + 42*tauw^2 - 21))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaW(1,2)*(3*taur + 3))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a6=(pozycjaA(1,2)*(6*taur^3*tauw^2 + 3*taur^3*tauw + taur^3 + 6*taur^2*tauw^3 + 21*taur^2*tauw^2 + 10*taur^2*tauw + 3*taur^2 + 3*taur*tauw^3 + 10*taur*tauw^2 + 3*taur*tauw + tauw^3 + 3*tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,2)*(6*taur^3*tauw^2 - 15*taur^3*tauw + 10*taur^3 + 6*taur^2*tauw^3 - 15*taur^2*tauw^2 + 10*taur^2*tauw - 15*taur*tauw^3 + 10*taur*tauw^2 + 42*taur*tauw - 42*taur + 10*tauw^3 - 42*tauw + 35))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaR(1,2)*(tauw + 3))/(taur^3*(taur - tauw)*(taur - 1)^3) + (pozycjaW(1,2)*(taur + 3))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a7=(pozycjaB(1,2)*(6*taur^2*tauw^2 - 15*taur^2*tauw + 10*taur^2 - 15*taur*tauw^2 + 37*taur*tauw - 24*taur + 10*tauw^2 - 24*tauw + 15))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaA(1,2)*(6*taur^2*tauw^2 + 3*taur^2*tauw + taur^2 + 3*taur*tauw^2 + taur*tauw + tauw^2))/(taur^3*tauw^3) + pozycjaR(1,2)/(taur^3*(taur - tauw)*(taur - 1)^3) - pozycjaW(1,2)/(tauw^3*(taur - tauw)*(tauw - 1)^3);
qtau32=a0+a1*tau+a2*tau.^2+a3*tau.^3+a4*tau.^4+a5*tau.^5+a6*tau.^6+a7*tau.^7;
dqtau32=(a1+2*a2*tau+3*a3*tau.^2+4*a4*tau.^3+5*a5*tau.^4+6*a6*tau.^5+7*a7*tau.^6)./tk;
ddqtau32=(2*a2+6*a3*tau+12*a4*tau.^2+20*a5*tau.^3+30*a6*tau.^4+42*a7*tau.^5)./tk.^2;

a0=pozycjaA(1,3);
a1=0;
a2=0;
a3=(pozycjaR(1,3)*tauw)/(taur^3*(taur - tauw)*(taur - 1)^3) - (pozycjaA(1,3)*(10*taur^3*tauw^3 + 6*taur^3*tauw^2 + 3*taur^3*tauw + taur^3 + 6*taur^2*tauw^3 + 3*taur^2*tauw^2 + taur^2*tauw + 3*taur*tauw^3 + taur*tauw^2 + tauw^3))/(taur^3*tauw^3) - (pozycjaW(1,3)*taur)/(tauw^3*(taur - tauw)*(tauw - 1)^3) + (pozycjaB(1,3)*taur*tauw*(10*taur^2*tauw^2 - 24*taur^2*tauw + 15*taur^2 - 24*taur*tauw^2 + 57*taur*tauw - 35*taur + 15*tauw^2 - 35*tauw + 21))/((taur - 1)^3*(tauw - 1)^3);
a4=(pozycjaA(1,3)*(15*taur^3*tauw^3 + 18*taur^3*tauw^2 + 9*taur^3*tauw + 3*taur^3 + 18*taur^2*tauw^3 + 15*taur^2*tauw^2 + 6*taur^2*tauw + taur^2 + 9*taur*tauw^3 + 6*taur*tauw^2 + taur*tauw + 3*tauw^3 + tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,3)*(15*taur^3*tauw^3 - 27*taur^3*tauw^2 + 15*taur^3 - 27*taur^2*tauw^3 + 42*taur^2*tauw^2 + 15*taur^2*tauw - 35*taur^2 + 15*taur*tauw^2 - 35*taur*tauw + 21*taur + 15*tauw^3 - 35*tauw^2 + 21*tauw))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaR(1,3)*(3*tauw + 1))/(taur^3*(taur - tauw)*(taur - 1)^3) + (pozycjaW(1,3)*(3*taur + 1))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a5=(pozycjaR(1,3)*(3*tauw + 3))/(taur^3*(taur - tauw)*(taur - 1)^3) - (pozycjaA(1,3)*(6*taur^3*tauw^3 + 18*taur^3*tauw^2 + 9*taur^3*tauw + 3*taur^3 + 18*taur^2*tauw^3 + 27*taur^2*tauw^2 + 12*taur^2*tauw + 3*taur^2 + 9*taur*tauw^3 + 12*taur*tauw^2 + 3*taur*tauw + 3*tauw^3 + 3*tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,3)*(27*taur^3*tauw - 6*taur^3*tauw^3 - 24*taur^3 + 27*taur^2*tauw^2 - 66*taur^2*tauw + 42*taur^2 + 27*taur*tauw^3 - 66*taur*tauw^2 + 42*taur*tauw - 24*tauw^3 + 42*tauw^2 - 21))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaW(1,3)*(3*taur + 3))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a6=(pozycjaA(1,3)*(6*taur^3*tauw^2 + 3*taur^3*tauw + taur^3 + 6*taur^2*tauw^3 + 21*taur^2*tauw^2 + 10*taur^2*tauw + 3*taur^2 + 3*taur*tauw^3 + 10*taur*tauw^2 + 3*taur*tauw + tauw^3 + 3*tauw^2))/(taur^3*tauw^3) - (pozycjaB(1,3)*(6*taur^3*tauw^2 - 15*taur^3*tauw + 10*taur^3 + 6*taur^2*tauw^3 - 15*taur^2*tauw^2 + 10*taur^2*tauw - 15*taur*tauw^3 + 10*taur*tauw^2 + 42*taur*tauw - 42*taur + 10*tauw^3 - 42*tauw + 35))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaR(1,3)*(tauw + 3))/(taur^3*(taur - tauw)*(taur - 1)^3) + (pozycjaW(1,3)*(taur + 3))/(tauw^3*(taur - tauw)*(tauw - 1)^3);
a7=(pozycjaB(1,3)*(6*taur^2*tauw^2 - 15*taur^2*tauw + 10*taur^2 - 15*taur*tauw^2 + 37*taur*tauw - 24*taur + 10*tauw^2 - 24*tauw + 15))/((taur - 1)^3*(tauw - 1)^3) - (pozycjaA(1,3)*(6*taur^2*tauw^2 + 3*taur^2*tauw + taur^2 + 3*taur*tauw^2 + taur*tauw + tauw^2))/(taur^3*tauw^3) + pozycjaR(1,3)/(taur^3*(taur - tauw)*(taur - 1)^3) - pozycjaW(1,3)/(tauw^3*(taur - tauw)*(tauw - 1)^3);
qtau33=a0+a1*tau+a2*tau.^2+a3*tau.^3+a4*tau.^4+a5*tau.^5+a6*tau.^6+a7*tau.^7;
dqtau33=(a1+2*a2*tau+3*a3*tau.^2+4*a4*tau.^3+5*a5*tau.^4+6*a6*tau.^5+7*a7*tau.^6)./tk;
ddqtau33=(2*a2+6*a3*tau+12*a4*tau.^2+20*a5*tau.^3+30*a6*tau.^4+42*a7*tau.^5)./tk.^2;

%wykresy przesunięcia
subplot(3,3,1)
plot(tau,qtau31,'g')
xlabel('\it\tau')
ylabel('theta1')

subplot(3,3,2)
plot(tau,qtau32,'g')
xlabel('\it\tau')
ylabel('theta2')

subplot(3,3,3)
plot(tau,qtau33,'g')
xlabel('\it\tau')
ylabel('lambda3')

% wykresy prędkości
subplot(3,3,4)
plot(tau,dqtau31,'b')
xlabel('\it\tau')
ylabel('dtheta1')

subplot(3,3,5)
plot(tau,dqtau32,'b')
xlabel('\it\tau')
ylabel('dtheta2')

subplot(3,3,6)
plot(tau,dqtau33,'b')
xlabel('\it\tau')
ylabel('dlambda3')

%wykresy przyspieszeń
subplot(3,3,7)
plot(tau,ddqtau31,'r')
xlabel('\it\tau')
ylabel('ddtheta1')

subplot(3,3,8)
plot(tau,ddqtau32,'r')
xlabel('\it\tau')
ylabel('ddtheta2')

subplot(3,3,9)
plot(tau,ddqtau33,'r')
xlabel('\it\tau')
ylabel('ddlambda3')