%planowanie trajektorii - wielomian stopnia 5

t=[t0:0.01:tk];
tau=t./tk;

a0=pozycjaA(1,1);
a1=0;
a2=0;
a3=10*(pozycjaB(1,1)-pozycjaA(1,1));
a4=15*(pozycjaA(1,1)-pozycjaB(1,1));
a5=6*(pozycjaB(1,1)-pozycjaA(1,1));
qtau21=a0+a1*tau+a2*(tau).^2+a3*(tau).^3+a4*(tau).^4+a5*(tau).^5; %droga
dqtau21=(a1+2*a2*tau+3*a3*(tau).^2+4*a4*(tau).^3+5*a5*(tau).^4)./tk;  %prędkość
ddqtau21=(2*a2+6*a3*tau+12*a4*(tau).^2+20*a5*(tau).^3)./(tk).^2;  %przyspieszenie

a0=pozycjaA(1,2);
a1=0;
a2=0;
a3=10*(pozycjaB(1,2)-pozycjaA(1,2));
a4=15*(pozycjaA(1,2)-pozycjaB(1,2));
a5=6*(pozycjaB(1,2)-pozycjaA(1,2));
qtau22=a0+a1*tau+a2*(tau).^2+a3*(tau).^3+a4*(tau).^4+a5*(tau).^5; %droga
dqtau22=(a1+2*a2*tau+3*a3*(tau).^2+4*a4*(tau).^3+5*a5*(tau).^4)./tk;  %prędkość
ddqtau22=(2*a2+6*a3*tau+12*a4*(tau).^2+20*a5*(tau).^3)./(tk).^2;  %przyspieszenie

a0=pozycjaA(1,3);
a1=0;
a2=0;
a3=10*(pozycjaB(1,3)-pozycjaA(1,3));
a4=15*(pozycjaA(1,3)-pozycjaB(1,3));
a5=6*(pozycjaB(1,3)-pozycjaA(1,3));
qtau23=a0+a1*tau+a2*(tau).^2+a3*(tau).^3+a4*(tau).^4+a5*(tau).^5; %droga
dqtau23=(a1+2*a2*tau+3*a3*(tau).^2+4*a4*(tau).^3+5*a5*(tau).^4)./tk;  %prędkość
ddqtau23=(2*a2+6*a3*tau+12*a4*(tau).^2+20*a5*(tau).^3)./(tk).^2;  %przyspieszenie

%wykresy przesunięcia
subplot(3,3,1)
plot(tau,qtau21,'g')
xlabel('\it\tau')
ylabel('theta1')

subplot(3,3,2)
plot(tau,qtau22,'g')
xlabel('\it\tau')
ylabel('theta2')

subplot(3,3,3)
plot(tau,qtau23,'g')
xlabel('\it\tau')
ylabel('lambda3')

% wykresy prędkości 
subplot(3,3,4)
plot(tau,dqtau21,'b')
xlabel('\it\tau')
ylabel('dtheta1')

subplot(3,3,5)
plot(tau,dqtau22,'b')
xlabel('\it\tau')
ylabel('dtheta2')

subplot(3,3,6)
plot(tau,dqtau23,'b')
xlabel('\it\tau')
ylabel('dlambda3')

%wykresy przyspieszeń 
subplot(3,3,7)
plot(tau,ddqtau21,'r')
xlabel('\it\tau')
ylabel('ddtheta1')

subplot(3,3,8)
plot(tau,ddqtau22,'r')
xlabel('\it\tau')
ylabel('ddtheta2')

subplot(3,3,9)
plot(tau,ddqtau23,'r')
xlabel('\it\tau')
ylabel('ddlambda3')


