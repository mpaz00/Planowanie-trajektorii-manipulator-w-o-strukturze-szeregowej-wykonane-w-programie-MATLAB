clear theta lambda l alpha theta1 theta2 theta3 lambda1 lambda2 lambda3 l1 l2 l3 alpha1 alpha2 alpha3

% L - macierz pomocnicza

theta1=pozycjaA(1,1);
theta2=pozycjaA(1,2);
lambda3=pozycjaA(1,3);

theta=[theta1 theta2 0];
lambda=[0 3 lambda3];
l=[1 0 3];
alpha=[3/2*pi 3/2*pi 0];

L=1;
k=length(theta)

%macierze Ai symbolicznie
for i=1:k;
    A=matrixA(theta(i),lambda(i),l(i),alpha(i));

    L=L*A
end
disp('Macierz orientacji w położeniu poczatkowym (DH)')
B30_A=[L(1,1) L(1,2) L(1,3);
     L(2,1) L(2,2) L(2,3);
     L(3,1) L(3,2) L(3,3)]

theta1=pozycjaB(1,1);
theta2=pozycjaB(1,2);
lambda3=pozycjaB(1,3);


L=1;
for i=1:k;
    A=matrixA(theta(i),lambda(i),l(i),alpha(i));

    L=L*A
end

disp('Macierz orientacji w położeniu końcowym (DH)')
B30_B=[L(1,1) L(1,2) L(1,3);
     L(2,1) L(2,2) L(2,3);
     L(3,1) L(3,2) L(3,3)]





