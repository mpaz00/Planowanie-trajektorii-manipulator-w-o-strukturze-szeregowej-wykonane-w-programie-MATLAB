

clc
clear all %czyszczenie przestrzeni roboczej
close all %zamknięcie wszystkich okien graficznych
disp({'Projekt 1';'Projekt wykonały: Mariola Paź i Karolina Niziołek'})
disp('Elementy i uklady sterowania robotów')
disp('Projekt zrealizowany w konwencji YZX dla kątów Eulera')
disp('wcisnij enter aby kontynuować')
pause

dane_planowania_trajektorii
zadanie_odwrotne
macierze_orientacji
wspolrzedne_DH
sprawdzenie_macierzy
menu_z_wyborem








